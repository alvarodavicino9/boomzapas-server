// ============================================
// BOOM ZAPAS - Servidor Backend
// Node.js + Express + Supabase + Mercado Pago
// ============================================

require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const { createClient } = require('@supabase/supabase-js');
const { MercadoPagoConfig, Preference, Payment } = require('mercadopago');

const app = express();
app.use(cors({ origin: ['https://boomzapas.netlify.app', 'http://localhost:3000'] }));
app.use(express.json());

// ── Supabase (usa service_role para tener acceso total) ──
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// ── Mercado Pago ──
const mpClient = new MercadoPagoConfig({
  accessToken: process.env.MP_ACCESS_TOKEN
});

// ============================================
// PRODUCTOS Y STOCK
// ============================================

// GET /api/productos — lista todos los productos con su stock
app.get('/api/productos', async (req, res) => {
  const { data: productos, error } = await supabase
    .from('productos')
    .select('*, stock(*)')
    .eq('activo', true)
    .order('id');

  if (error) return res.status(500).json({ error: error.message });
  res.json(productos);
});

// GET /api/stock/:productoId — stock de un producto específico
app.get('/api/stock/:productoId', async (req, res) => {
  const { data, error } = await supabase
    .from('stock')
    .select('talle, cantidad')
    .eq('producto_id', req.params.productoId)
    .order('talle');

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ============================================
// PEDIDOS
// ============================================

// POST /api/pedido — crea un pedido nuevo
app.post('/api/pedido', async (req, res) => {
  const { cliente, items, metodo_pago, notas } = req.body;

  // Validar que hay stock para cada item
  for (const item of items) {
    const { data: stockData } = await supabase
      .from('stock')
      .select('cantidad')
      .eq('producto_id', item.producto_id)
      .eq('talle', item.talle)
      .single();

    if (!stockData || stockData.cantidad < item.cantidad) {
      return res.status(400).json({
        error: `Sin stock para producto ${item.producto_id} talle ${item.talle}`
      });
    }
  }

  // Crear o encontrar cliente
  let clienteId = null;
  if (cliente.email || cliente.telefono) {
    const { data: clienteExistente } = await supabase
      .from('clientes')
      .select('id')
      .or(`email.eq.${cliente.email},telefono.eq.${cliente.telefono}`)
      .single();

    if (clienteExistente) {
      clienteId = clienteExistente.id;
    } else {
      const { data: nuevoCliente } = await supabase
        .from('clientes')
        .insert(cliente)
        .select('id')
        .single();
      clienteId = nuevoCliente?.id;
    }
  }

  // Calcular total
  const total = items.reduce((sum, i) => sum + i.precio_unit * i.cantidad, 0);

  // Crear pedido
  const { data: pedido, error: pedidoError } = await supabase
    .from('pedidos')
    .insert({ cliente_id: clienteId, total, estado: 'pendiente', metodo_pago, notas })
    .select('id')
    .single();

  if (pedidoError) return res.status(500).json({ error: pedidoError.message });

  // Insertar items
  const pedidoItems = items.map(i => ({ ...i, pedido_id: pedido.id }));
  await supabase.from('pedido_items').insert(pedidoItems);

  res.json({ ok: true, pedido_id: pedido.id, total });
});

// ============================================
// MERCADO PAGO
// ============================================

// POST /api/mp/crear-preferencia — genera el link de pago de MP
app.post('/api/mp/crear-preferencia', async (req, res) => {
  const { items, pedido_id, cliente } = req.body;

  try {
    const preference = new Preference(mpClient);
    const result = await preference.create({
      body: {
        items: items.map(i => ({
          id:          String(i.producto_id),
          title:       `${i.nombre} talle ${i.talle}`,
          quantity:    i.cantidad,
          unit_price:  i.precio_unit,
          currency_id: 'ARS'
        })),
        payer: {
          name:  cliente?.nombre || '',
          email: cliente?.email  || 'comprador@boomzapas.com'
        },
        back_urls: {
          success: `https://boomzapas.netlify.app?pago=ok&pedido=${pedido_id}`,
          failure: `https://boomzapas.netlify.app?pago=error&pedido=${pedido_id}`,
          pending: `https://boomzapas.netlify.app?pago=pendiente&pedido=${pedido_id}`
        },
        auto_return:        'approved',
        notification_url:   `${process.env.SERVER_URL}/api/mp/webhook`,
        external_reference: String(pedido_id),
        statement_descriptor: 'BOOM ZAPAS'
      }
    });

    res.json({
      init_point:    result.init_point,      // link para pagar
      preference_id: result.id
    });
  } catch (err) {
    console.error('MP error:', err);
    res.status(500).json({ error: err.message });
  }
});

// POST /api/mp/webhook — MP llama aquí cuando se confirma un pago
app.post('/api/mp/webhook', async (req, res) => {
  const { type, data } = req.body;

  if (type !== 'payment') return res.sendStatus(200);

  try {
    const payment = new Payment(mpClient);
    const paymentData = await payment.get({ id: data.id });

    if (paymentData.status !== 'approved') return res.sendStatus(200);

    const pedidoId = parseInt(paymentData.external_reference);

    // Actualizar pedido a pagado
    await supabase
      .from('pedidos')
      .update({ estado: 'pagado', mp_payment_id: String(data.id) })
      .eq('id', pedidoId);

    // Descontar stock para cada item del pedido
    const { data: items } = await supabase
      .from('pedido_items')
      .select('*')
      .eq('pedido_id', pedidoId);

    for (const item of items) {
      await supabase.rpc('descontar_stock', {
        p_producto_id: item.producto_id,
        p_talle:       item.talle,
        p_cantidad:    item.cantidad
      });
    }

    console.log(`✅ Pago confirmado - Pedido #${pedidoId}`);
    res.sendStatus(200);
  } catch (err) {
    console.error('Webhook error:', err);
    res.sendStatus(500);
  }
});

// ============================================
// PANEL DE ADMIN — rutas protegidas
// ============================================

// Middleware simple de autenticación
const adminAuth = (req, res, next) => {
  const token = req.headers['x-admin-token'];
  if (token !== process.env.ADMIN_TOKEN) {
    return res.status(401).json({ error: 'No autorizado' });
  }
  next();
};

// GET /api/admin/pedidos — todos los pedidos
app.get('/api/admin/pedidos', adminAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('vista_pedidos')
    .select('*')
    .limit(100);
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// PATCH /api/admin/pedido/:id — actualizar estado de pedido
app.patch('/api/admin/pedido/:id', adminAuth, async (req, res) => {
  const { estado } = req.body;
  const { data, error } = await supabase
    .from('pedidos')
    .update({ estado })
    .eq('id', req.params.id)
    .select()
    .single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// PATCH /api/admin/stock — actualizar stock de un talle
app.patch('/api/admin/stock', adminAuth, async (req, res) => {
  const { producto_id, talle, cantidad } = req.body;
  const { data, error } = await supabase
    .from('stock')
    .upsert({ producto_id, talle, cantidad })
    .select()
    .single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// GET /api/admin/stats — resumen del negocio
app.get('/api/admin/stats', adminAuth, async (req, res) => {
  const [pedidos, stockBajo] = await Promise.all([
    supabase.from('pedidos').select('estado, total'),
    supabase.from('stock').select('*, productos(nombre)').lt('cantidad', 3)
  ]);

  const stats = {
    total_pedidos:   pedidos.data?.length || 0,
    pedidos_pagados: pedidos.data?.filter(p => p.estado === 'pagado').length || 0,
    ingresos_total:  pedidos.data?.filter(p => p.estado === 'pagado').reduce((s, p) => s + Number(p.total), 0) || 0,
    stock_bajo:      stockBajo.data || []
  };

  res.json(stats);
});

// ── Health check ──
app.get('/', (req, res) => res.json({ status: 'ok', app: 'Boom Zapas API' }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`🚀 Boom Zapas server corriendo en puerto ${PORT}`));

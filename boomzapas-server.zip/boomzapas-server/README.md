# Boom Zapas — Servidor Backend

## Stack
- Node.js + Express
- Supabase (base de datos)
- Mercado Pago (pagos)
- Railway (hosting)

## Pasos para subir a Railway

### 1. Instalar Railway CLI
```bash
npm install -g @railway/cli
railway login
```

### 2. Crear proyecto en Railway
```bash
railway init
# Elegí "Empty Project" → nombre: boomzapas-server
```

### 3. Configurar variables de entorno en Railway
En el dashboard de Railway → tu proyecto → Variables:
```
SUPABASE_URL         = https://cllcxtapymvvjaracuvc.supabase.co
SUPABASE_SERVICE_KEY = (tu service_role key de Supabase)
MP_ACCESS_TOKEN      = (tu access token de Mercado Pago)
SERVER_URL           = (la URL que te da Railway, ej: https://boomzapas-server.railway.app)
ADMIN_TOKEN          = (inventate un token secreto largo)
PORT                 = 3001
```

### 4. Subir el servidor
```bash
railway up
```

Railway te da una URL pública tipo:
`https://boomzapas-server-production.railway.app`

### 5. Actualizar SERVER_URL
Copiar esa URL y pegarla en la variable SERVER_URL de Railway.

---

## Endpoints disponibles

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | /api/productos | Lista productos con stock |
| GET | /api/stock/:id | Stock de un producto |
| POST | /api/pedido | Crear pedido nuevo |
| POST | /api/mp/crear-preferencia | Generar link de pago MP |
| POST | /api/mp/webhook | Webhook de confirmación MP |
| GET | /api/admin/pedidos | Ver todos los pedidos (admin) |
| PATCH | /api/admin/pedido/:id | Cambiar estado pedido (admin) |
| PATCH | /api/admin/stock | Actualizar stock (admin) |
| GET | /api/admin/stats | Estadísticas del negocio (admin) |

## Rutas de admin
Requieren header: `x-admin-token: tu_admin_token`
